//----------------------------------*-C++-*-----------------------------------//
/**
 *  @file  NonlinearResidual.i.hh
 *  @brief NonlinearResidual inline member definitions
 *  @note  Copyright (C) 2013 Jeremy Roberts
 */
//----------------------------------------------------------------------------//

#ifndef erme_solver_NONLINEARRESIDUAL_I_HH_
#define erme_solver_NONLINEARRESIDUAL_I_HH_

#include "comm/Comm.hh"
#include <cmath>

namespace erme_solver
{



} // end namespace erme_solver

#endif // erme_solver_NONLINEARRESIDUAL_I_HH_

//----------------------------------------------------------------------------//
//              end of file NonlinearResidual.i.hh
//----------------------------------------------------------------------------//
