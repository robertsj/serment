//----------------------------------*-C++-*----------------------------------//
/*!
 * \file   InnerIterBase.cc
 * \author Jeremy Roberts
 * \date   Nov 7, 2011
 * \brief  InnerIterBase member and MR wrapper definitions.
 * \note   Copyright (C) 2011 Jeremy Roberts. 
 */
//---------------------------------------------------------------------------//
// $Rev::                                               $:Rev of last commit
// $Author:: j.alyn.roberts@gmail.com                   $:Author of last commit
// $Date::                                              $:Date of last commit
//---------------------------------------------------------------------------//

#include "InnerIterBase.hh"




//---------------------------------------------------------------------------//
//              end of InnerIterBase.cc
//---------------------------------------------------------------------------//
