serment
=======

An implementation of the eigenvalue response matrix method.

Originally, serment stood for Solving Eigenvalue Response Matrix
Equations using Newton's Technique; however, a more accurate
description substitutes Nonlinear Techniques for Newton's 
Technique.


